package com.cts.student.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.student.entities.Student;

public interface StudentDao extends JpaRepository<Student, Integer> {

}
