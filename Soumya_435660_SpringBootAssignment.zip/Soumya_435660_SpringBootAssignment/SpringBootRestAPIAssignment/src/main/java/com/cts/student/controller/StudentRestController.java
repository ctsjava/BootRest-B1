package com.cts.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.student.dao.StudentDao;
import com.cts.student.entities.Student;

import antlr.collections.List;

@RestController
@RequestMapping("api/students")
@CrossOrigin
public class StudentRestController {

	@Autowired
	private StudentDao dao;
	@PostMapping
	public ResponseEntity<Student> saveStudent(@RequestBody Student student){
		return ResponseEntity.ok(dao.save(student));
	}
	@GetMapping
	public ResponseEntity<?> getStudentInfo(){
	return ResponseEntity.ok(dao.findAll());
	}
}
